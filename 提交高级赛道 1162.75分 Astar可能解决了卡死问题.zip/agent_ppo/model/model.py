#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors
"""


from typing import List
import torch
from torch import nn
import numpy as np
from agent_ppo.conf.conf import Config

import sys
import os

if os.path.basename(sys.argv[0]) == "learner.py":
    import torch

    torch.set_num_interop_threads(2)
    torch.set_num_threads(2)
else:
    import torch

    torch.set_num_interop_threads(4)
    torch.set_num_threads(4)


class CNN(nn.Module):
    """CNN网络处理128x128的全地图feature"""
    def __init__(self, input_channels=1, output_dim=256):
        super().__init__()
        self.conv_layers = nn.Sequential(
            # 第一层卷积: 128x128 -> 64x64
            nn.Conv2d(input_channels, 32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.SiLU(),
            
            # 第二层卷积: 64x64 -> 32x32
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.SiLU(),
            
            # 第三层卷积: 32x32 -> 16x16
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.SiLU(),
            
            # 第四层卷积: 16x16 -> 8x8
            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(256),
            nn.SiLU(),
            
            # 第五层卷积: 8x8 -> 4x4
            nn.Conv2d(256, 512, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(512),
            nn.SiLU(),
        )
        
        # 全局平均池化 + 全连接层
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(512, output_dim)
        
        # 初始化权重
        self._init_weights()
    
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.orthogonal(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.orthogonal(m.weight)
                nn.init.zeros_(m.bias)
    
    def forward(self, x):
        # x shape: (batch_size, 128, 128)
        # 添加channel维度: (batch_size, 1, 128, 128)
        if x.dim() == 3:
            x = x.unsqueeze(1)
        
        x = self.conv_layers(x)
        x = self.global_pool(x)
        x = x.view(x.size(0), -1)  # Flatten
        x = self.fc(x)
        return x


class NetworkModelBase(nn.Module):
    def __init__(self):
        super().__init__()
        # feature configure parameter
        # 特征配置参数
        self.data_split_shape = Config.DATA_SPLIT_SHAPE
        self.feature_split_shape = Config.FEATURE_SPLIT_SHAPE
        self.cnn_data_length = Config.CNN_FEATURES
        self.label_size = Config.ACTION_NUM
        self.feature_len_without_cnn = Config.FEATURE_LEN - Config.CNN_FEATURES
        self.value_num = Config.VALUE_NUM

        self.var_beta = Config.BETA_START
        self.vf_coef = Config.VF_COEF

        self.clip_param = Config.CLIP_PARAM

        self.data_len = Config.data_len

        # Main MLP network
        # 主MLP网络
        self.main_fc_dim_list = [self.feature_len_without_cnn, 256, 256]
        self.main_mlp_net = MLP(self.main_fc_dim_list, "main_mlp_net", non_linearity_last=True)
        
        # CNN network for processing 128x128 map features
        # CNN网络处理128x128地图特征
        self.cnn_net = CNN(input_channels=1, output_dim=256)
        
        # Feature fusion layer
        # 特征融合层
        self.fusion_layer = MLP([512, 256], "fusion_layer", non_linearity_last=True)
        
        self.label_mlp = MLP([256, 64, self.label_size], "label_mlp")
        self.value_mlp = MLP([256, 64, self.value_num], "value_mlp")

    def process_legal_action(self, label, legal_action):
        label_max, _ = torch.max(label * legal_action, 1, True)
        label = label - label_max
        label = label * legal_action
        label = label + 1e5 * (legal_action - 1)
        return label

    def forward(self, feature, legal_action):
        # Split features
        # 分割特征
        全地图feature = feature[:, :self.cnn_data_length].reshape(-1, 128, 128)
        精简feature = feature[:, self.cnn_data_length:]

        # Process with main MLP
        # 主MLP处理
        fc_mlp_out = self.main_mlp_net(精简feature)
        
        # Process with CNN
        # CNN处理
        cnn_out = self.cnn_net(全地图feature)
        
        # Feature fusion
        # 特征融合
        combined_features = torch.cat([fc_mlp_out, cnn_out], dim=1)
        fused_features = self.fusion_layer(combined_features)

        # Action and value processing
        # 处理动作和值
        label_mlp_out = self.label_mlp(fused_features)
        label_out = self.process_legal_action(label_mlp_out, legal_action)

        prob = torch.nn.functional.softmax(label_out, dim=1)
        value = self.value_mlp(fused_features)

        return prob, value


class NetworkModelActor(NetworkModelBase):
    def format_data(self, obs, legal_action):
        return (
            torch.tensor(obs).to(torch.float32),
            torch.tensor(legal_action).to(torch.float32),
        )


class NetworkModelLearner(NetworkModelBase):
    def format_data(self, datas):
        return datas.view(-1, self.data_len).float().split(self.data_split_shape, dim=1)

    def forward(self, data_list, inference=False):
        feature = data_list[0]
        legal_action = data_list[-1]
        return super().forward(feature, legal_action)


def make_fc_layer(in_features: int, out_features: int):
    # Wrapper function to create and initialize a linear layer
    # 创建并初始化一个线性层
    fc_layer = nn.Linear(in_features, out_features)

    # initialize weight and bias
    # 初始化权重及偏移量
    nn.init.orthogonal(fc_layer.weight)
    nn.init.zeros_(fc_layer.bias)

    return fc_layer


class MLP(nn.Module):
    def __init__(
        self,
        fc_feat_dim_list: List[int],
        name: str,
        non_linearity: nn.Module = nn.SiLU,
        non_linearity_last: bool = False,
    ):
        # Create a MLP object
        # 创建一个 MLP 对象
        super().__init__()
        self.fc_layers = nn.Sequential()
        for i in range(len(fc_feat_dim_list) - 1):
            fc_layer = make_fc_layer(fc_feat_dim_list[i], fc_feat_dim_list[i + 1])
            self.fc_layers.add_module("{0}_fc{1}".format(name, i + 1), fc_layer)
            
            # Add LayerNorm after each linear layer (except the last one if non_linearity_last is False)
            # 在每个线性层后添加LayerNorm（除非是最后一层且non_linearity_last为False）
            if i + 1 < len(fc_feat_dim_list) - 1 or non_linearity_last:
                # Add LayerNorm before non-linearity
                # 在非线性激活前添加LayerNorm
                self.fc_layers.add_module("{0}_norm{1}".format(name, i + 1), nn.LayerNorm(fc_feat_dim_list[i + 1]))
                self.fc_layers.add_module("{0}_non_linear{1}".format(name, i + 1), non_linearity())

    def forward(self, data):
        return self.fc_layers(data)
