#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors
"""


import torch
import numpy as np
from torch import nn
import torch.nn.functional as F
from typing import List
from agent_dqn.conf.conf import Config

import sys
import os

if os.path.basename(sys.argv[0]) == "learner.py":
    import torch

    torch.set_num_interop_threads(2)
    torch.set_num_threads(2)
else:
    import torch

    torch.set_num_interop_threads(4)
    torch.set_num_threads(4)


class CNN(nn.Module):
    """CNN网络处理128x128的全地图feature"""
    def __init__(self, input_channels=1, output_dim=256):
        super().__init__()
        self.conv_layers = nn.Sequential(
            # 第一层卷积: 128x128 -> 64x64
            nn.Conv2d(input_channels, 32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.SiLU(),
            
            # 第二层卷积: 64x64 -> 32x32
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.SiLU(),
            
            # 第三层卷积: 32x32 -> 16x16
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.SiLU(),
            
            # 第四层卷积: 16x16 -> 8x8
            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(256),
            nn.SiLU(),
            
            # 第五层卷积: 8x8 -> 4x4
            nn.Conv2d(256, 512, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(512),
            nn.SiLU(),
        )
        
        # 全局平均池化 + 全连接层
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(512, output_dim)
        
        # 初始化权重
        self._init_weights()
    
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.orthogonal(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.orthogonal(m.weight)
                nn.init.zeros_(m.bias)
    
    def forward(self, x):
        # x shape: (batch_size, 128, 128)
        # 添加channel维度: (batch_size, 1, 128, 128)
        if x.dim() == 3:
            x = x.unsqueeze(1)
        
        x = self.conv_layers(x)
        x = self.global_pool(x)
        x = x.view(x.size(0), -1)  # Flatten
        x = self.fc(x)
        return x


class Model(nn.Module):
    def __init__(self, state_shape, action_shape=0, softmax=False):
        super().__init__()
        # feature configure parameter
        # 特征配置参数
        self.feature_len = Config.DIM_OF_OBSERVATION
        self.cnn_data_length = Config.CNN_FEATURES
        self.feature_len_without_cnn = self.feature_len - self.cnn_data_length

        # Main MLP network for non-CNN features
        # 主MLP网络处理非CNN特征
        self.main_fc_dim_list = [self.feature_len_without_cnn, 256, 256]
        self.main_mlp_net = MLP(self.main_fc_dim_list, "main_mlp_net", non_linearity_last=True)
        
        # CNN network for processing 128x128 map features
        # CNN网络处理128x128地图特征
        self.cnn_net = CNN(input_channels=1, output_dim=256)
        
        # Feature fusion layer
        # 特征融合层
        self.fusion_layer = MLP([512, 256], "fusion_layer", non_linearity_last=True)

        # Q network
        # Q 网络
        self.q_mlp = MLP([256, 128, action_shape], "q_mlp")

    # Forward inference
    # 前向推理
    def forward(self, feature):
        # Split features
        # 分割特征
        全地图feature = feature[:, :self.cnn_data_length].reshape(-1, 128, 128)
        精简feature = feature[:, self.cnn_data_length:]

        # Process with main MLP
        # 主MLP处理
        fc_mlp_out = self.main_mlp_net(精简feature)
        
        # Process with CNN
        # CNN处理
        cnn_out = self.cnn_net(全地图feature)
        
        # Feature fusion
        # 特征融合
        combined_features = torch.cat([fc_mlp_out, cnn_out], dim=1)
        fused_features = self.fusion_layer(combined_features)

        # Action and value processing
        # 处理动作和值
        logits = self.q_mlp(fused_features)
        return logits


def make_fc_layer(in_features: int, out_features: int):
    # Wrapper function to create and initialize a linear layer
    # 创建并初始化一个线性层
    fc_layer = nn.Linear(in_features, out_features)

    # initialize weight and bias
    # 初始化权重及偏移量
    nn.init.orthogonal(fc_layer.weight)
    nn.init.zeros_(fc_layer.bias)

    return fc_layer


class MLP(nn.Module):
    def __init__(
        self,
        fc_feat_dim_list: List[int],
        name: str,
        non_linearity: nn.Module = nn.SiLU,
        non_linearity_last: bool = False,
    ):
        # Create a MLP object
        # 创建一个 MLP 对象
        super().__init__()
        self.fc_layers = nn.Sequential()
        for i in range(len(fc_feat_dim_list) - 1):
            fc_layer = make_fc_layer(fc_feat_dim_list[i], fc_feat_dim_list[i + 1])
            self.fc_layers.add_module("{0}_fc{1}".format(name, i + 1), fc_layer)
            
            # Add LayerNorm after each linear layer (except the last one if non_linearity_last is False)
            # 在每个线性层后添加LayerNorm（除非是最后一层且non_linearity_last为False）
            if i + 1 < len(fc_feat_dim_list) - 1 or non_linearity_last:
                # Add LayerNorm before non-linearity
                # 在非线性激活前添加LayerNorm
                self.fc_layers.add_module("{0}_norm{1}".format(name, i + 1), nn.LayerNorm(fc_feat_dim_list[i + 1]))
                self.fc_layers.add_module("{0}_non_linear{1}".format(name, i + 1), non_linearity())

    def forward(self, data):
        return self.fc_layers(data)
