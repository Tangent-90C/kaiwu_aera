#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################

"""
Author: Tencent AI Arena Authors

"""

import numpy as np
import math
from agent_dqn.feature.definition import RelativeDistance, RelativeDirection, DirectionAngles, reward_process


def norm(v, max_v, min_v=0):
    v = np.maximum(np.minimum(max_v, v), min_v)
    return (v - min_v) / (max_v - min_v)


class Preprocessor:
    def __init__(self) -> None:
        self.move_action_num = 8
        self.reset()

    def reset(self):
        self.step_no = 0
        self.cur_pos = (0, 0)
        self.上次的pos = (-1, -1)
        self.cur_pos_norm = np.array((0, 0))
        self.end_pos = None
        self.is_end_pos_found = False
        self.history_pos = []
        self.拿到的宝箱数量 = 0
        self.全局地图 = np.full([128, 128], -0.5, dtype=np.float32) # -0.5是没探索的
        self.没改过的全局地图 = np.full([128, 128], -10, dtype=np.int32) # -10是没探索的，-1不可走，1可走，2宝箱，3终点
        self.已经探明的宝箱位置 = []
        self.bad_move_ids = set()

    def _get_pos_feature(self, found, cur_pos, target_pos):
        relative_pos = tuple(y - x for x, y in zip(cur_pos, target_pos))
        dist = np.linalg.norm(relative_pos)
        target_pos_norm = norm(target_pos, 128, -128)
        feature = np.array(
            (
                found,
                norm(relative_pos[0] / max(dist, 1e-4), 1, -1),
                norm(relative_pos[1] / max(dist, 1e-4), 1, -1),
                target_pos_norm[0],
                target_pos_norm[1],
                norm(dist, 1.41 * 128),
            ),
        )
        return feature

    def pb2struct(self, frame_state, last_action):
        obs, extra_info = frame_state
        self.step_no = obs["frame_state"]["step_no"]

        hero = obs["frame_state"]["heroes"][0]
        self.cur_pos = (hero["pos"]["x"], hero["pos"]["z"])

        # History position
        # 历史位置
        self.history_pos.append(self.cur_pos)
        if len(self.history_pos) > 10:
            self.history_pos.pop(0)

        # End position
        # 终点位置
        for organ in obs["frame_state"]["organs"]:
            if organ["sub_type"] == 4:
                end_pos_dis = RelativeDistance[organ["relative_pos"]["l2_distance"]]
                end_pos_dir = RelativeDirection[organ["relative_pos"]["direction"]]
                if organ["status"] != -1:
                    self.end_pos = (organ["pos"]["x"], organ["pos"]["z"])
                    self.is_end_pos_found = True
                # if end_pos is not found, use relative position to predict end_pos
                # 如果终点位置未找到，使用相对位置预测终点位置
                elif (not self.is_end_pos_found) and (
                    self.end_pos is None
                    or self.step_no % 100 == 0
                    or self.end_pos_dir != end_pos_dir
                    or self.end_pos_dis != end_pos_dis
                ):
                    distance = end_pos_dis * 20
                    theta = DirectionAngles[end_pos_dir]
                    delta_x = distance * math.cos(math.radians(theta))
                    delta_z = distance * math.sin(math.radians(theta))

                    self.end_pos = (
                        max(0, min(128, round(self.cur_pos[0] + delta_x))),
                        max(0, min(128, round(self.cur_pos[1] + delta_z))),
                    )

                    self.end_pos_dir = end_pos_dir
                    self.end_pos_dis = end_pos_dis

        self.last_pos_norm = self.cur_pos_norm
        self.cur_pos_norm = norm(self.cur_pos, 128, -128)
        self.feature_end_pos = self._get_pos_feature(self.is_end_pos_found, self.cur_pos, self.end_pos)

        # History position feature
        # 历史位置特征
        self.feature_history_pos = self._get_pos_feature(1, self.cur_pos, self.history_pos[0])

        self.move_usable = True
        self.last_action = last_action

    def process(self, frame_state, last_action):
        self.pb2struct(frame_state, last_action)

        # Legal action
        # 合法动作
        legal_action = self.get_legal_action()
        
        地图 = np.zeros([11, 11], dtype=np.int32)
        可以通行 = np.zeros([11, 11], dtype=np.float32)
        终点位置 = np.zeros([11, 11], dtype=np.float32)
        宝箱位置 = np.zeros([11, 11], dtype=np.float32)
        加速增益位置 = np.zeros([11, 11], dtype=np.float32)

        for i in range(11):
            地图[i, :] = frame_state[0]['map_info'][i]['values']
            
        可以通行[地图 != 0] = 1.0
        终点位置[地图 == 3] = 1.0
        宝箱位置[地图 == 4] = 1.0
        加速增益位置[地图 == 6] = 1.0

        # 根据 "可以通行" 矩阵来将地图信息填充到全局地图中，注意3个要求
        # 1. 只将 可以通行 中数值为0，即不可通行的地方标记为 -1 
        # 2. 将 Agent 所在位置数值 + 0.1
        # 3. 要根据 Agent 所在位置self.cur_pos的偏移量换算，全局地图是128x128，可以通行 是 Agent 为中心的 11x11 矩阵
        
        # 计算Agent在全局地图中的中心位置
        center_x = int(self.cur_pos[0])
        center_z = int(self.cur_pos[1])
        
        # 遍历11x11的可以通行矩阵
        for i in range(11):
            for j in range(11):
                # 计算在全局地图中的对应位置
                global_x = center_x - 5 + i
                global_z = center_z - 5 + j
                
                # 确保位置在全局地图范围内
                if 0 <= global_x < 128 and 0 <= global_z < 128:
                    # 如果该位置不可通行（可以通行[i,j] == 0），标记为-1
                    if 可以通行[i, j] == 0.0:
                        self.全局地图[global_x, global_z] = -1
                        self.没改过的全局地图[global_x, global_z] = -1

                    if 可以通行[i, j] == 1.0 and self.全局地图[global_x, global_z] == -0.5:
                        self.没改过的全局地图[global_x, global_z] = 1
                        self.全局地图[global_x, global_z] = 0

                    if 宝箱位置[i,j ] == 1.0:
                        # 只有第一次探到宝箱才改地图
                        current_pos = (global_x, global_z)
                        if current_pos not in self.已经探明的宝箱位置:
                            self.已经探明的宝箱位置.append(current_pos)
                            self.没改过的全局地图[global_x, global_z] = 2

                    if 终点位置[i,j ] == 1.0:
                        self.没改过的全局地图[global_x, global_z] = 3

                    
                    # 如果是Agent所在位置（i=5, j=5，即11x11矩阵的中心），数值+0.1
                    if i == 5 and j == 5:
                        self.全局地图[global_x, global_z] += 0.1
                        
                        # self.没改过的全局地图[global_x, global_z] = 1 # 表示可以通行，此外把宝箱洗掉
                        # 1. 中心坐标
                        cx, cz = global_x, global_z

                        # 2. 生成 3×3 邻域偏移量（含自身）
                        delta = np.arange(-1, 2)
                        dx, dz = np.meshgrid(delta, delta, indexing='ij')   # shape (3,3)
                        coords = np.stack([dx.ravel() + cx, dz.ravel() + cz], axis=1)  # shape (9,2)

                        # 3. 筛掉越界坐标
                        h, w = self.没改过的全局地图.shape
                        mask = ((coords[:, 0] >= 0) & (coords[:, 0] < h) &
                                (coords[:, 1] >= 0) & (coords[:, 1] < w))
                        coords = coords[mask]

                        # 4. 找到值为 2 的格子
                        ix, iz = coords[:, 0], coords[:, 1]
                        mask_chest = self.没改过的全局地图[ix, iz] == 2

                        # 5. 改成 1
                        self.没改过的全局地图[ix[mask_chest], iz[mask_chest]] = 1


        可以通行 = 可以通行.reshape(-1)
        终点位置 = 终点位置.reshape(-1)
        宝箱位置 = 宝箱位置.reshape(-1)
        加速增益位置 = 加速增益位置.reshape(-1)

    
        if (self.上次的pos != self.cur_pos):
            是否撞墙 = False
        else:
            是否撞墙 = True

        self.上次的pos = self.cur_pos


        是否在绕圈 = False
        try:
            pos = self.cur_pos
            # self.step_no 是步数
            
            # 检测是否在绕圈
            if len(self.history_pos) >= 8:  # 至少需要8个历史位置来判断
                # 方法1: 检查最近几个位置是否形成闭合路径
                recent_positions = self.history_pos[-8:]  # 取最近8个位置
                
                # 计算路径的总长度和起点到终点的距离
                total_path_length = 0
                for i in range(1, len(recent_positions)):
                    dx = recent_positions[i][0] - recent_positions[i-1][0]
                    dy = recent_positions[i][1] - recent_positions[i-1][1]
                    total_path_length += math.sqrt(dx*dx + dy*dy)
                
                # 起点到终点的直线距离
                start_to_end_dx = recent_positions[-1][0] - recent_positions[0][0]
                start_to_end_dy = recent_positions[-1][1] - recent_positions[0][1]
                start_to_end_distance = math.sqrt(start_to_end_dx*start_to_end_dx + start_to_end_dy*start_to_end_dy)
                
                # 如果路径长度远大于起点到终点的距离，说明在绕圈
                if total_path_length > 0 and start_to_end_distance < total_path_length * 0.3:
                    是否在绕圈 = True
                
                # # 方法2: 检查是否有重复的位置模式
                if not 是否在绕圈:
                    # 检查最近几个位置是否在很小的范围内波动
                    x_coords = [pos[0] for pos in recent_positions]
                    y_coords = [pos[1] for pos in recent_positions]
                    
                    x_range = max(x_coords) - min(x_coords)
                    y_range = max(y_coords) - min(y_coords)
                    
                    # 如果x和y的变化范围都很小，说明在原地徘徊
                    if x_range < 4 and y_range < 4:
                        是否在绕圈 = True
                
                # 方法3: 检查是否有重复的位置
                if not 是否在绕圈:
                    unique_positions = set()
                    for pos in recent_positions:
                        # 将位置四舍五入到整数，避免浮点数精度问题
                        rounded_pos = (round(pos[0]), round(pos[1]))
                        unique_positions.add(rounded_pos)
                    
                    # 如果唯一位置数量很少，说明在重复访问相同位置
                    if len(unique_positions) <= 3:
                        是否在绕圈 = True

        except Exception as e:
            pass

        # Feature
        # 特征
        # 物件类型，1代表宝箱, 2代表加速buff,3代表起点,4代表终点

        step_norm = self.step_no / 1000 - 1
        扁平化的全局地图 = self.全局地图.reshape(-1) 
        # shape 是 (16384,)
        feature = np.concatenate([扁平化的全局地图, 可以通行, 终点位置, 宝箱位置, 加速增益位置, self.cur_pos_norm, self.feature_end_pos, self.feature_history_pos, legal_action, np.array(step_norm).reshape(-1)])
        # 

        是否拿到宝箱 = False
        if frame_state[0]['score_info']['treasure_collected_count'] > self.拿到的宝箱数量:
            是否拿到宝箱 = True
            self.拿到的宝箱数量 = frame_state[0]['score_info']['treasure_collected_count']

        

        return (
            feature,
            legal_action,
            reward_process(self.feature_end_pos[-1], self.feature_history_pos[-1], 是否拿到宝箱, 是否在绕圈, self.step_no, 是否撞墙),
            self.没改过的全局地图,
            self.cur_pos,
            self.拿到的宝箱数量,
            是否在绕圈,
        )

    def get_legal_action(self):
        # if last_action is move and current position is the same as last position, add this action to bad_move_ids
        # 如果上一步的动作是移动，且当前位置与上一步位置相同，则将该动作加入到bad_move_ids中
        if (
            abs(self.cur_pos_norm[0] - self.last_pos_norm[0]) < 0.001
            and abs(self.cur_pos_norm[1] - self.last_pos_norm[1]) < 0.001
            and self.last_action > -1
        ):
            self.bad_move_ids.add(self.last_action)
        else:
            self.bad_move_ids = set()

        legal_action = [self.move_usable] * self.move_action_num
        for move_id in self.bad_move_ids:
            legal_action[move_id] = 0

        if self.move_usable not in legal_action:
            self.bad_move_ids = set()
            return [self.move_usable] * self.move_action_num

        return legal_action
