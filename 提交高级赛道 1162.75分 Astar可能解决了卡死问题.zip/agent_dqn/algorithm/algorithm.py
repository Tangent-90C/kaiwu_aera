#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors
"""


import time
import random
import os
import numpy as np
import torch
import heapq
import traceback
from collections import deque
from typing import List, Tuple
import base64


from agent_dqn.conf.conf import Config
from agent_dqn.model.model import Model
from agent_dqn.feature.definition import ActData


class Algorithm:
    def __init__(self, device, logger, monitor):
        self.act_shape = Config.DIM_OF_ACTION_DIRECTION
        self.direction_space = Config.DIM_OF_ACTION_DIRECTION
        self.talent_direction = Config.DIM_OF_TALENT
        self.obs_shape = Config.DIM_OF_OBSERVATION
        self.epsilon_max = Config.EPSILON_MAX
        self.epsilon_min = Config.EPSILON_MIN
        self.epsilon_decay = Config.EPSILON_DECAY
        self._gamma = Config.GAMMA
        self.lr = Config.START_LR
        self.device = device
        self.model = Model(
            state_shape=self.obs_shape,
            action_shape=self.act_shape,
            softmax=False,
        )
        self.model.to(self.device)
        self.optim = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        self.train_step = 0
        self.predict_count = 0
        self.last_report_monitor_time = 0
        self.logger = logger
        self.monitor = monitor

        self.run_idx = 0
        self.A_star_目标 = (None, None)
        
        # A*探索策略相关参数
        self.collect_all_chests = True  # 是否优先收集所有宝箱
        self.astar_exploration_prob = 0  # A*探索的概率（在epsilon探索中的比例）

        self.上次的dx = 0
        self.上次的dy = 0

        self.随机游走的步数 = 0
        self.检测绕圈步数 = 0

        self.终点位置 = (None, None)
        self.A星路径规划失败次数 = 0
        self.终点周围位置 = []
    


        self.direction_offsets = [
            (1, 0),  # 0 右
            (1, 1),  # 1 右上角
            (0, 1),   # 2 上
            (-1, 1),   # 3 左上角
            (-1, 0),   # 4 左
            (-1, -1),  # 5 左下角
            (0, -1),  # 6 下
            (1, -1), # 7 右下角
        ]

        # 映射到8个方向
        self.direction_map = {
            (1, 0): 0,   # 右
            (1, 1): 1,  # 右上角
            (0, 1): 2,  # 上
            (-1, 1): 3, # 左上角
            (-1, 0): 4,  # 左
            (-1, -1): 5,  # 左下角
            (0, -1): 6,   # 下
            (1, -1): 7,   # 右下角
        }
        
        # A*算法记忆功能
        self.current_paths = {}  # 保存每个agent的当前路径
        self.current_targets = {}  # 保存每个agent的当前目标
        self.debug_mode = True  # 调试开关，默认开启
        self.LOG_FILE = 'map.log'

    def set_debug_mode(self, enabled):
        """设置调试模式开关"""
        self.debug_mode = enabled
        self.logger.info(f"调试模式已{'开启' if enabled else '关闭'}")

    def manhattan_distance(self, pos1, pos2):
        """计算曼哈顿距离"""
        return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

    def is_reachable(self, start, end, map_data):
        """检查从起点到终点是否可达"""
        if start == end:
            return True

        # BFS初始化
        visited = set()
        # queue = [start]
        queue = deque([start])

        
        visited.add(start)

        while queue:
            # x, y = queue.pop(0)
            x, y = queue.popleft()      # 代替 pop(0)

            # 检查八个方向
            for dx, dy in self.direction_offsets:
                nx, ny = x + dx, y + dy

                # 如果到达终点
                if (nx, ny) == end:
                    return True

                # 检查是否有效且未访问
                if self.is_valid_position(nx, ny, map_data) and (nx, ny) not in visited:
                    visited.add((nx, ny))
                    queue.append((nx, ny))

        return False
    


    def is_valid_position(self, x, y, map_data, *, check_two_step=False, dx=0, dy=0):
        """检查 (x,y) 是否可走；若 check_two_step=True，则还要保证再走 (dx,dy) 一步也安全。"""
        if not (0 <= x < 128 and 0 <= y < 128):
            return False
        if map_data[x, y] not in {1, 2, 3}:   # 1:路 2:宝箱 3:出口
            return False
        if check_two_step:
            nx, ny = x + dx, y + dy
            if not (0 <= nx < 128 and 0 <= ny < 128):
                return False
            if map_data[nx, ny] not in {1, 2, 3}:
                return False
        return True



    def get_neighbors(self, pos, map_data, 拿到的宝箱数量):
        """返回所有满足‘两步安全’的邻居。"""
        x, y = pos
        neighbors = []
        for dx, dy in self.direction_offsets:
            nx, ny = x + dx, y + dy
            if self.is_valid_position(nx, ny, map_data, check_two_step=True, dx=dx, dy=dy):
                if 拿到的宝箱数量 >= 8 or self.终点位置 == (None, None):
                    neighbors.append((nx, ny))
                else:
                    if (nx, ny) not in self.终点周围位置:
                        neighbors.append((nx, ny))

        return neighbors

    
    def a_star_pathfinding(self, start, goal, map_data, 额外debug信息, 拿到的宝箱数量):
        """A*路径规划算法"""
        if self.debug_mode:
            self.logger.info(f" A*开始路径规划: 起点={start}, 终点={goal}")
            额外debug信息 = 额外debug信息 + f' A*开始路径规划: 起点={start}, 终点={goal}'
            
        if not self.is_valid_position(start[0], start[1], map_data) or not self.is_valid_position(goal[0], goal[1], map_data):
            if self.debug_mode:
                if not self.is_valid_position(start[0], start[1], map_data):
                    self.logger.warning(f" A*路径规划失败: 起点无效")
                    额外debug信息 = 额外debug信息 + f' A*路径规划失败: 起点无效'
                if not self.is_valid_position(goal[0], goal[1], map_data):
                    self.logger.warning(f" A*路径规划失败: 起点无效")
                    额外debug信息 = 额外debug信息 + f' A*路径规划失败: 起点无效'
            return None
        
        open_set = [(0, start)]
        heapq.heapify(open_set)
        came_from = {}
        g_score = {start: 0}
        f_score = {start: self.manhattan_distance(start, goal)}
        
        step_count = 0
        max_steps = 4000  # 防止无限循环
        
        while open_set and step_count < max_steps:
            step_count += 1
            current_f, current = heapq.heappop(open_set)
            
            if self.debug_mode and step_count % 500 == 0:
                self.logger.info(f" A*搜索中... 步数: {step_count}, 当前位置: {current}")
            
            #if current == goal:
            if self.manhattan_distance(current, goal) <= 1:
                # 重建路径
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                path.reverse()
                if self.debug_mode:
                    self.logger.info(f" A*路径规划成功: 路径长度={len(path)}, 步数={step_count}")
                    self.logger.info(f" 完整路径: {path}")
                return path
            
            for neighbor in self.get_neighbors(current, map_data, 拿到的宝箱数量):
                tentative_g_score = g_score[current] + 1
                
                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + self.manhattan_distance(neighbor, goal)
                    
                    if neighbor not in [item[1] for item in open_set]:
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))
        
        if self.debug_mode:
            
            def file_to_base64(file_path):
                with open(file_path, "rb") as file:  # ⚠️ 二进制模式打开文件
                    file_content = file.read()
                    base64_data = base64.b64encode(file_content)  # 编码为base64字节串
                    base64_text = base64_data.decode("utf-8")    # 转为字符串
                return base64_text

            if self.A星路径规划失败次数 % 30 == 0:
                self.logger.warning(f" A*路径规划失败: 步数={step_count}, open_set剩余={len(open_set)} {file_to_base64('map.log')}")
            else:
                self.logger.warning(f" A*路径规划失败: 步数={step_count}, open_set剩余={len(open_set)}")
            self.A星路径规划失败次数 += 1


        return None

    def 看看旁边有没有墙(self, agent_pos, map_data):
        h, w = map_data.shape
        r, c = agent_pos        # 要检查的中心坐标

        # 4 个方向偏移：上、下、左、右
        dr = np.array([-1, 1, 0, 0])
        dc = np.array([ 0, 0,-1, 1])

        nr = r + dr
        nc = c + dc

        # 合法掩码：不越界
        mask = (0 <= nr) & (nr < h) & (0 <= nc) & (nc < w)

        # 存在 -1 ？
        has_minus1 = np.any(map_data[nr[mask], nc[mask]] == -1)

        return has_minus1



    
    def find_target_position(self, agent_pos, map_data, 拿到的宝箱数量):
        """根据策略找到目标位置"""
        x, y = agent_pos
        
        if self.debug_mode:
            self.logger.info(f" 开始寻找目标位置，当前agent位置: ({x}, {y})")
        
        # 1. 优先找宝箱
        chests = list(zip(*np.where(map_data == 2)))
        
        if self.debug_mode:
            self.logger.info(f" 发现宝箱数量: {len(chests)}, collect_all_chests: {self.collect_all_chests}")
        
        if chests and self.collect_all_chests:
            # 找到最近的宝箱
            nearest_chest = min(chests, key=lambda pos: self.manhattan_distance(agent_pos, pos))
            if self.debug_mode:
                self.logger.info(f" 选择最近宝箱: {nearest_chest}, 距离: {self.manhattan_distance(agent_pos, nearest_chest)}")
            return nearest_chest
        


        if self.终点位置 == (None, None):
            end_pos_arr = np.argwhere(map_data == 3)
            if end_pos_arr.size > 0:           # 有终点
                end_pos = tuple(end_pos_arr[0])
                self.logger.warning(f'发现终点位置 {end_pos}')
                self.终点位置 = end_pos
                终点周围位置 = [self.终点位置]
                for i in [-1, 0, 1]:
                    for j in [-1, 0, 1]:
                        if abs(i) != abs(j):
                            终点周围位置.append((self.终点位置[0] + i, self.终点位置[1] + j)) 
                self.终点周围位置 = 终点周围位置

        else:
            if 拿到的宝箱数量 >= 8:
                if self.debug_mode:
                    self.logger.info(f"选择最后的终点: {self.终点位置}")
                return self.终点位置


        # 3. 找未探索的区域旁边的可走位置
        unexplored_adjacent = []
        for i in range(128):
            for j in range(128):
                if map_data[i, j] == -10:  # 未探索
                    # 检查周围是否有可走的路
                    for dx, dy in self.direction_offsets:
                        check_x, check_y = i + dx * 2, j + dy * 2
                        if self.is_valid_position(check_x, check_y, map_data):
                            if self.看看旁边有没有墙((check_x, check_y), map_data):
                                # self.logger.warning('检测到有墙，跳过')
                                pass
                            elif (check_x, check_y) in self.终点周围位置:
                                # 避免误入终点
                                pass
                            else:
                                unexplored_adjacent.append((check_x, check_y))


        

        

        if self.debug_mode:
            self.logger.info(f" 未探索区域相邻位置数量: {len(unexplored_adjacent)}")

        # 过滤出可达的位置
        reachable_positions = []
        for pos in unexplored_adjacent:
            if self.is_reachable(agent_pos, pos, map_data):
                reachable_positions.append(pos)

        if self.debug_mode:
            self.logger.info(f" 可达位置数量: {len(reachable_positions)}")


        k = 5  # 前 k 个里随机
        if reachable_positions:
            # 按距离升序排序，只保留前 k 个
            sorted_pos = sorted(reachable_positions,
                                key=lambda p: self.manhattan_distance(agent_pos, p))[:k]
            chosen = random.choice(sorted_pos)

            if self.debug_mode:
                self.logger.info(f" 从前{k}个最近位置随机选择: {chosen}, "
                                f"距离: {self.manhattan_distance(agent_pos, chosen)}")
            return chosen


        if self.debug_mode:
            self.logger.info(" 没有找到合适的目标位置")
        return None
    
    def get_direction_to_target(self, agent_pos, target_pos):
        """获取从当前位置到目标位置的方向"""
        if target_pos is None:
            if self.debug_mode:
                self.logger.warning(" 目标位置为None，无法计算方向")
            return None
        
        dx = target_pos[0] - agent_pos[0]
        dy = target_pos[1] - agent_pos[1]
        
        if self.debug_mode:
            self.logger.info(f" 计算方向: agent_pos={agent_pos}, target_pos={target_pos}, dx={dx}, dy={dy}")
        
        # 标准化方向
        if dx > 0:
            dx = 1
        elif dx < 0:
            dx = -1
        if dy > 0:
            dy = 1
        elif dy < 0:
            dy = -1

        
        direction = self.direction_map.get((dx, dy), 0)
        if self.debug_mode:
            self.logger.info(f" 计算得到方向: {direction}")
        return direction, dx, dy

    def learn(self, list_sample_data):

        t_data = list_sample_data
        batch = len(t_data)

        batch_feature_vec = [frame.obs for frame in t_data]
        batch_action = torch.LongTensor(np.array([int(frame.act) for frame in t_data])).view(-1, 1).to(self.device)
        _batch_obs_legal = torch.stack([frame._obs_legal for frame in t_data]).bool().to(self.device)
        _batch_feature_vec = [frame._obs for frame in t_data]

        rew = torch.tensor(
            [frame.rew.cpu().item() if isinstance(frame.rew, torch.Tensor) else frame.rew for frame in t_data],
            device=self.device,
        )
        not_done = torch.tensor(
            [
                0 if (frame.done.cpu().item() if isinstance(frame.done, torch.Tensor) else frame.done) == 1 else 1
                for frame in t_data
            ],
            device=self.device,
        )
        batch_feature = self.__convert_to_tensor(batch_feature_vec)
        _batch_feature = self.__convert_to_tensor(_batch_feature_vec)

        model = getattr(self, "model")
        model.eval()
        with torch.no_grad():
            q = model(_batch_feature)
            q = q.masked_fill(~_batch_obs_legal, float(torch.min(q)))
            q_max = q.max(dim=1).values.detach()

        target_q = rew + self._gamma * q_max * not_done

        self.optim.zero_grad()

        model = getattr(self, "model")
        model.train()
        logits = model(batch_feature)

        loss = torch.square(target_q - logits.gather(1, batch_action).view(-1)).mean()
        loss.backward()
        model_grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        self.optim.step()

        self.train_step += 1

        value_loss = loss.detach().item()
        q_value = target_q.mean().detach().item()
        reward = rew.mean().detach().item()

        # Periodically report monitoring
        # 按照间隔上报监控
        now = time.time()
        if now - self.last_report_monitor_time >= 60:
            monitor_data = {
                "value_loss": value_loss,
                "q_value": q_value,
                "reward": reward,
            }
            if self.monitor:
                self.monitor.put_data({os.getpid(): monitor_data})

            self.last_report_monitor_time = now

    def __convert_to_tensor(self, data):
        # Please check the data type carefully and make sure it is float32
        # 请仔细检查数据类型，确保是 float32
        if isinstance(data, list):
            if isinstance(data[0], torch.Tensor):
                processed = torch.stack(data, dim=0).to(self.device).float()
            elif isinstance(data[0], np.ndarray):
                processed = torch.from_numpy(np.stack(data, axis=0)).to(self.device).float()
            else:
                processed = torch.tensor(np.array(data), dtype=torch.float32).to(self.device)
        elif isinstance(data, np.ndarray):
            processed = torch.from_numpy(data.astype(np.float32)).to(self.device)
        elif torch.is_tensor(data):
            processed = data.to(self.device).float()
        else:
            raise TypeError(f"Unsupported data type: {type(data)}")
        return processed


    def frame_to_text(self, matrix):
        """把矩阵变成一行字符串（128 个字符），无换行"""
        trans = {-10: '□', -1: '■', 1: ' ', 2: 'B', 3: 'E', 4: '☺', 5: '√'}
        return ''.join(trans[int(v)] for v in matrix)


    # 1. 新增：检查“再走一步是否撞墙”的函数
    def _can_move_two_steps(self, x, y, dx, dy, map_data):
        """
        判断从 (x,y) 沿 (dx,dy) 方向能否连续走两步而不撞墙。
        agent 没有“不动”这一 action，因此只要下一步或下下一步非法，即视为不可行。
        """
        nx1, ny1 = x + dx, y + dy          # 下一格
        nx2, ny2 = x + dx * 2, y + dy * 2  # 下下格
        return (self.is_valid_position(nx1, ny1, map_data) and
                self.is_valid_position(nx2, ny2, map_data))


    def predict_detail(self, list_obs_data, exploit_flag=False, exploit_only=False):
        
        batch = len(list_obs_data)

        feature_vec = [obs_data.feature for obs_data in list_obs_data]
        legal_act = [obs_data.legal_act for obs_data in list_obs_data]
        全局地图s = [obs_data.full_map for obs_data in list_obs_data]
        agent_positionss = [obs_data.cur_pos for obs_data in list_obs_data]
        拿到的宝箱数量s = [obs_data.box_num for obs_data in list_obs_data]
        is_绕圈s = [obs_data.is_绕圈 for obs_data in list_obs_data]
        # agent_positions 是 (x, y)
        legal_act = torch.tensor(np.array(legal_act)).bool().to(self.device)

        model = self.model
        model.eval()

        # Exploration factor,
        # we want epsilon to decrease as the number of prediction steps increases, until it reaches 0.1
        # 探索因子, 我们希望epsilon随着预测步数越来越小，直到0.1为止
        self.epsilon = self.epsilon_min + (self.epsilon_max - self.epsilon_min) * np.exp(
            -self.epsilon_decay * self.predict_count
        )

        with torch.no_grad():
            # 检查是否使用A*探索策略
            use_astar_exploration = (
                not exploit_flag and 
                np.random.rand(1) < self.epsilon and 
                np.random.rand(1) < self.astar_exploration_prob and
                全局地图s is not None and 
                agent_positionss is not None or
                exploit_only
            )

            额外debug信息 = ''
            dx = '无'
            dy = '无'
            
            if use_astar_exploration:
                # 使用A*算法进行探索
                act = []
                for i in range(batch):
                    try:
                        agent_pos = agent_positionss[i]  # 获取第i个agent的位置
                        全局地图 = 全局地图s[i]  # 获取第i个agent的地图
                        拿到的宝箱数量 = 拿到的宝箱数量s[i]
                        is_绕圈 = is_绕圈s[i]

                        self.检测绕圈步数 -= 1
                        self.随机游走的步数 -= 1
                        if is_绕圈 == True and self.检测绕圈步数 <= 0:
                            if self.debug_mode:
                                self.logger.info(f" 检测到Agent在绕圈，开始随机游走以改出")
                                self.logger.info(f" 检测到Agent在绕圈，开始随机游走以改出")
                            self.随机游走的步数 = 7
                            self.检测绕圈步数 = 20


                        if self.debug_mode:
                            self.logger.info(f" === 开始预测 agent_id={i}, 当前位置={agent_pos} ===")
                            self.logger.info(f" 当前路径状态: current_paths={list(self.current_paths.keys())}, current_targets={list(self.current_targets.keys())}")
                            额外debug信息 = 额外debug信息 + f' === 开始预测 agent_id={i}, 当前位置={agent_pos} ==='
                        
                        # 检查数据有效性
                        if agent_pos is None or 全局地图 is None:
                            # 数据无效，使用随机探索
                            direction = np.random.randint(0, self.act_shape)
                            if self.debug_mode:
                                self.logger.info(f" 数据无效，使用随机探索, 方向={direction}")
                                额外debug信息 = 额外debug信息 + f' 数据无效，使用随机探索, 方向={direction}'
                        elif self.随机游走的步数 > 0:
                            direction = np.random.randint(0, self.act_shape)
                            if self.debug_mode:
                                self.logger.info(f" 使用随机探索改出绕圈, 方向={direction}")
                                额外debug信息 = 额外debug信息 + f' 使用随机探索改出绕圈, 方向={direction}'
                        else:
                            agent_id = i
                            
                            # 检查是否有未完成的路径
                            if agent_id in self.current_paths and self.current_paths[agent_id]:
                                current_path = self.current_paths[agent_id]
                                
                                if self.debug_mode:
                                    self.logger.info(f" 发现未完成路径: 路径长度={len(current_path)}")
                                    self.logger.info(f" 完整路径: {current_path}")
                                    额外debug信息 = 额外debug信息 + f' 发现未完成路径: 路径={current_path}'
                                
                                预防过点的坐标 = (agent_pos[0] - self.上次的dx, agent_pos[1] - self.上次的dy)
                                # 检查当前位置是否在路径上
                                if agent_pos in current_path or 预防过点的坐标 in current_path:

                                    if 预防过点的坐标 in current_path and agent_pos not in current_path:
                                        if self.debug_mode:
                                            # self.logger.warning(f" 检测到模型跨过目标点")
                                            额外debug信息 = 额外debug信息 + f' 检测到模型跨过目标点'
                                        current_idx = current_path.index(预防过点的坐标)
                                    else:
                                        current_idx = current_path.index(agent_pos)
                                    
                                    if self.debug_mode:
                                        self.logger.info(f" 当前位置在路径中，索引={current_idx}, 总长度={len(current_path)}")
                                        额外debug信息 = 额外debug信息 + f' 当前位置在路径中，索引={current_idx}, 总长度={len(current_path)}'
                                    
                                    if current_idx < len(current_path) - 1:
                                        # 继续沿原路径走
                                        next_pos = current_path[current_idx + 1]
                                        direction, dx, dy = self.get_direction_to_target(agent_pos, next_pos)
                                        if self.debug_mode:
                                            self.logger.info(f" 继续原路径: 下一位置={next_pos}, 方向={direction}")
                                            额外debug信息 = 额外debug信息 + f' 继续原路径: 下一位置={next_pos}, 方向={direction}'
                                    else:
                                        # 已到达路径终点，清除路径
                                        if self.debug_mode:
                                            self.logger.info(" 已到达路径终点，清除路径")
                                        self.current_paths[agent_id] = []
                                        self.current_targets[agent_id] = None
                                        target_pos = self.find_target_position(agent_pos, 全局地图, 拿到的宝箱数量)
                                        if target_pos is not None:
                                            self.A_star_目标 = target_pos
                                        else:
                                            self.A_star_目标 = (None, None)
                                        
                                        if target_pos is not None:
                                            path = self.a_star_pathfinding(agent_pos, target_pos, 全局地图, 额外debug信息, 拿到的宝箱数量)
                                            if path and len(path) > 1:
                                                self.current_paths[agent_id] = path
                                                self.current_targets[agent_id] = target_pos
                                                next_pos = path[1]
                                                direction, dx, dy = self.get_direction_to_target(agent_pos, next_pos)
                                                if self.debug_mode:
                                                    self.logger.info(f" 新路径规划成功: 目标={target_pos}, 下一位置={next_pos}, 方向={direction}")
                                                    额外debug信息 = 额外debug信息 + f' 路径规划失败，直接指向目标: 目标={target_pos}, 方向={direction}'
                                            else:
                                                direction, dx, dy = self.get_direction_to_target(agent_pos, target_pos)
                                                if self.debug_mode:
                                                    self.logger.info(f" 路径规划失败，直接指向目标: 目标={target_pos}, 方向={direction}")
                                                    额外debug信息 = 额外debug信息 + f' 路径规划失败，直接指向目标: 目标={target_pos}, 方向={direction}'
                                        else:
                                            direction = np.random.randint(0, self.act_shape)
                                            if self.debug_mode:
                                                self.logger.info(f" 无目标位置，随机方向={direction}")
                                                额外debug信息 = 额外debug信息 + f' 无目标位置，随机方向={direction}'
                                else:
                                    # 不在原路径上，重新规划
                                    if self.debug_mode:
                                        self.logger.info(f" 当前位置不在路径中，重新规划路径，预设路径为 {current_path}，当前位置是 {agent_pos}")
                                        self.logger.info(f" 当前位置: {agent_pos}, 路径: {current_path}")
                                    self.current_paths[agent_id] = []
                                    self.current_targets[agent_id] = None
                                    target_pos = self.find_target_position(agent_pos, 全局地图, 拿到的宝箱数量)
                                    if target_pos is not None:
                                        self.A_star_目标 = target_pos
                                    else:
                                        self.A_star_目标 = (None, None)
                                    
                                    if target_pos is not None:
                                        path = self.a_star_pathfinding(agent_pos, target_pos, 全局地图, 额外debug信息, 拿到的宝箱数量)
                                        if path and len(path) > 1:
                                            self.current_paths[agent_id] = path
                                            self.current_targets[agent_id] = target_pos
                                            next_pos = path[1]
                                            direction, dx, dy = self.get_direction_to_target(agent_pos, next_pos)
                                            if self.debug_mode:
                                                self.logger.info(f" 重新规划成功: 目标={target_pos}, 下一位置={next_pos}, 方向={direction}")
                                                额外debug信息 = 额外debug信息 + f' 重新规划成功: 目标={target_pos}, 下一位置={next_pos}, 方向={direction}'
                                        else:
                                            direction, dx, dy = self.get_direction_to_target(agent_pos, target_pos)
                                            if self.debug_mode:
                                                self.logger.info(f" 重新规划失败，直接指向目标: 目标={target_pos}, 方向={direction}")
                                                额外debug信息 = 额外debug信息 + f' 重新规划失败，直接指向目标: 目标={target_pos}, 方向={direction}'
                                    else:
                                        direction = np.random.randint(0, self.act_shape)
                                        if self.debug_mode:
                                            self.logger.info(f" 无目标位置，随机方向={direction}")
                                            额外debug信息 = 额外debug信息 + f' 无目标位置，随机方向={direction}'
                            else:
                                # 没有现有路径，重新规划
                                if self.debug_mode:
                                    self.logger.info(" 没有现有路径，开始新规划...")
                                    额外debug信息 = 额外debug信息 + f' 没有现有路径，开始新规划...'
                                target_pos = self.find_target_position(agent_pos, 全局地图, 拿到的宝箱数量)
                                
                                if target_pos is not None:
                                    self.A_star_目标 = target_pos
                                else:
                                    self.A_star_目标 = (None, None)

                                if target_pos is not None:
                                    path = self.a_star_pathfinding(agent_pos, target_pos, 全局地图, 额外debug信息, 拿到的宝箱数量)
                                    if path and len(path) > 1:
                                        self.current_paths[agent_id] = path
                                        self.current_targets[agent_id] = target_pos
                                        next_pos = path[1]
                                        direction, dx, dy = self.get_direction_to_target(agent_pos, next_pos)
                                        if self.debug_mode:
                                            self.logger.info(f" 新路径规划成功: 目标={target_pos}, 下一位置={next_pos}, 方向={direction}")
                                            额外debug信息 = 额外debug信息 + f' 新路径规划成功: 目标={target_pos}, 下一位置={next_pos}, 方向={direction}'
                                    else:
                                        direction, dx, dy = self.get_direction_to_target(agent_pos, target_pos)
                                        if self.debug_mode:
                                            # self.logger.info(f" 路径规划失败，直接指向目标: 目标={target_pos}, 方向={direction}")
                                            额外debug信息 = 额外debug信息 + f' 路径规划失败，直接指向目标: 目标={target_pos}, 方向={direction}'
                                else:
                                    direction = np.random.randint(0, self.act_shape)
                                    if self.debug_mode:
                                        #self.logger.info(f" 无目标位置，随机方向={direction}")
                                        额外debug信息 = 额外debug信息 + f' 无目标位置，随机方向={direction}'
                        

                        # 原方向不合法 → 从 legal_act[i] 中为 True 的动作里随机挑一个
                        if not legal_act[i, direction]:
                            legal_directions = torch.where(legal_act[i])[0]
                            if len(legal_directions) > 0:
                                old_direction = direction
                                direction = legal_directions[torch.randint(len(legal_directions), (1,))].item()
                                if self.debug_mode:
                                    self.logger.info(f" 方向不合法，随机修正: {old_direction} -> {direction}")
                                    额外debug信息 += f' 方向不合法，随机修正: {old_direction} -> {direction}'
                            else:
                                raise Exception('不可能没合法方向的')
                                # direction = 0
                                # if self.debug_mode:
                                #     self.logger.info(f" 无合法方向，默认方向={direction}")
                                #     额外debug信息 = 额外debug信息 + f' 无合法方向，设默认方向={direction}'
                        
                        if self.debug_mode:
                            self.logger.info(f" 最终选择方向: {direction}")

                        
                        inv_action_map = {v: k for k, v in self.direction_map.items()}
                        self.上次的dx = inv_action_map[direction][0]
                        self.上次的dy = inv_action_map[direction][1]
                        
                        act.append([direction])
                    except Exception as e:
                        # 如果A*探索出现错误，回退到随机探索
                        if self.logger:
                            self.logger.warning(f"A* exploration failed for batch {i}: {e}", exc_info=True)
                            # 2) 或者把调用栈抓到字符串里
                            stack_str = traceback.format_exc()
                            self.logger.warning(stack_str)          # 或写到文件、调试窗口等
                            # self.logger.warning(f"{e.stack}")
                            # logger.error(..., )
                        direction = np.random.randint(0, self.act_shape)
                        if not legal_act[i, direction]:
                            legal_directions = torch.where(legal_act[i])[0]
                            if len(legal_directions) > 0:
                                direction = legal_directions[0].item()
                            else:
                                direction = 0
                        act.append([direction])
                        self.logger.info(f" A*探索出现错误，回退到随机探索，方向: {direction}")
                        额外debug信息 = 额外debug信息 + f' A*探索出现错误，回退到随机探索，方向: {direction}'
            elif not exploit_flag and np.random.rand(1) < self.epsilon:
                # 传统的epsilon贪婪随机探索
                random_action = np.random.rand(batch, self.act_shape)
                random_action = torch.tensor(random_action, dtype=torch.float32).to(self.device)
                random_action = random_action.masked_fill(~legal_act, 0)
                act = random_action.argmax(dim=1).cpu().view(-1, 1).tolist()
                if self.debug_mode:
                    self.logger.info(f" 使用随机探索，epsilon={self.epsilon}")
                    额外debug信息 = 额外debug信息 + f' 使用随机探索，epsilon={self.epsilon}'
            else:
                # 使用模型预测
                feature = self.__convert_to_tensor(feature_vec)
                logits = model(feature)
                logits = logits.masked_fill(~legal_act, float(torch.min(logits)))
                act = logits.argmax(dim=1).cpu().view(-1, 1).tolist()
                if self.debug_mode:
                    self.logger.info(f" 使用模型预测")
                    额外debug信息 = 额外debug信息 + f' 使用模型预测'

        # act = [[2]]

        format_action = [[instance[0] % self.direction_space, instance[0] // self.direction_space] for instance in act]
        self.predict_count += 1

        #self.logger.flush()
        self.run_idx += 1

        if i == 0:
            全局地图_bak = 全局地图.copy()
            全局地图_bak[agent_pos[0], agent_pos[1]] = 4

            if self.A_star_目标 != (None, None):
                全局地图_bak[self.A_star_目标[0], self.A_star_目标[1]] = 5

            # 如果文件已存在则覆盖；也可以改成追加
            with open(self.LOG_FILE, 'a', buffering=1) as f:
                # 写一整幅地图：128 行 + 一个分隔符行
                for row in 全局地图_bak:
                    f.write(self.frame_to_text(row) + '\n')
                f.write(f'--- {self.run_idx} action {format_action[0][0]}, 下一步运动方向: ({dx}, {dy}) , 当前位置 ({agent_pos[0]}, {agent_pos[1]}), {额外debug信息}\n')      # 帧分隔符


        return [ActData(move_dir=j[0], use_talent=j[1]) for j in format_action]
